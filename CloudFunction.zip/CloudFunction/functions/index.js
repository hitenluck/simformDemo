const functions = require('firebase-functions');

const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);

exports.pushNotification = functions.database.ref('/chat/{reationShipId}/{messageId}').onWrite((change, context) => {

    //  Grab the current value of what was written to the Realtime Database.
    const original = change.after.val();
      console.log('Uppercasing', original);
      // Create a notification
          const payload = {
              notification: {
                  title:original.user.username,
                  body: original.text,
                  sound: "default"
              },
          };


 var pushid= original.user.pushToken;
 // var pushid = 'fDdgZCsVs8U:APA91bHwRN-pig0RwJlTONzwIQu8EMLT-GKW7vTPzY5XNQqLZy9_O2cE7JLzgKBiO_8iFynAEO6CYfas9PgAtsnMugnJwvVkjZOXN5AlSViu7Ouk7wDuNnFBZEgR8te7q2VGo-7BpC27'

          return admin.messaging().sendToDevice(pushid,payload)
          .then(function (response) {
                    console.log("Successfully sent message:", response);
                    console.log(response.results)
                })
                .catch(function (error) {
                    console.log("Error sending message:", error);
                });
});
